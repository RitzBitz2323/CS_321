
public class D_Instruction extends Instruction {
	private String DT_address;
	private String op;
	private String Rn;
	private String Rt;

	public D_Instruction(String name, String remainingBinary) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printInstruction() {
		// TODO Auto-generated method stub
		
	}

}
