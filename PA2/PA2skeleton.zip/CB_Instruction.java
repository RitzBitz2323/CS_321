
public class CB_Instruction extends Instruction {
	private String COND_BR_address;
	private String Rt;

	public CB_Instruction(String name, String remainingBinary) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printInstruction() {
		// TODO Auto-generated method stub
		
	}

}
