
public class I_Instruction extends Instruction {
	private String ALU_immediate;
	private String Rn;
	private String Rt;

	public I_Instruction(String name, String remainingBinary) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printInstruction() {
		// TODO Auto-generated method stub
		
	}

}
