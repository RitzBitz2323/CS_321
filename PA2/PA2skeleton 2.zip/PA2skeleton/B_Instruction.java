
public class B_Instruction extends Instruction {
	private String BR_address;

	public B_Instruction(String name, String remainingBinary) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printInstruction() {
		// TODO Auto-generated method stub
		
	}

}
