
public class IW_Instruction extends Instruction{

	private String MOV_immediate;
	private String Rd;
	
	public IW_Instruction(String name, String remainingBinary) {		
		
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printInstruction() {
		// TODO Auto-generated method stub
		
	}

}
